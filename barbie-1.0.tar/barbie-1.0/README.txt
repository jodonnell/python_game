Bubble Kong
===========

Entry in PyWeek #4  <http://www.pyweek.org/4/>
Team: The Olde Battleaxe
Members: philhassey, pekuja, tim, drpetter, gerry

(for the original source, and level editor)
svn://www.imitationpickles.org/pyweek4/trunk

DEPENDENCIES:

You might need to install some of these before running the game:

  Python:     http://www.python.org/
  PyGame:     http://www.pygame.org/


RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

Othewise open a terminal / console and "cd" to the game directory and run:

  python run_game.py

-full : to run in windows mode
-scale2x : use the scale2x scaler
-lowres : to run in 320x240
-tv : to do a silly scanline effect

level.tga : to play a certain level

HOW TO PLAY THE GAME:

Use your arrow keys to
move the seahorse.
Button 1 - Jump 
Button 2 - Shoot
            
Enemies take 3 shots unless
you are powered up!  You can
ride enemy bubbles.


MISC:

press 'd' on the main menu to enter 'debug' mode and have a list of all
levels in the data/levels/ folder.  That way you can play in development
or totally broken / reject levels.

LICENSE:

(c) 2007 The Olde Battleaxe & Friends
