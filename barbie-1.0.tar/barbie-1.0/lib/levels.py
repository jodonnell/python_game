LEVELS = [
    ('phil_1.tga',      'Jungle - 1',),
    ('phil_7.tga',      'Jungle - 2',),
    ('tim_2.tga',       'Jungle - 3',),
    ('phil_2.tga',      'Jungle - 4',),
    ('phil_13.tga',     'Jungle - 5',),
    
    ('pekuja_3.tga',    'Volcano - 1',),
    ('tim_4.tga',       'Volcano - 2',),
    ('phil_14.tga',     'Volcano - 3',),
    ('phil_8.tga',      'Bonus',),
    
    ('phil_12.tga',     'Moon - 1',),
    ('pekuja_1.tga',    'Moon - 2',),
    ('phil_5.tga',      'Moon - 3',),
    ('phil_10.tga',     'Moon - 4',),
    ('boss_1.tga',      'Boss',),
    
    #('phil_1.tga',      'Jungle - 1',), # jungle - easy
    #('phil_7.tga',      'Jungle - 2',), # jungle - medium 
    #('tee_1.tga',       'Jungle - 3',), # jungle - hard
    #('phil_2.tga',      'Jungle - 4',), # jungle - hard
    
    #('fydo_1.tga',      'Volcano - 1',), # volcano - easy
    #('tim_1.tga',       'Volcano - 2',), # volcano - medium
    #('pekuja_2.tga',    'Volcano - 3',), # volcano - medium
    #('phil_8.tga',      '* Bonus *',), # volcano bonus 
    
    #('pekuja_1.tga',    'Moon - 1',), # moon - medium
    #('phil_5.tga',      'Moon - 2',), # moon - medium 
    #('phil_9.tga',      'Moon - 3',), # moon - medium
    #('boss_1.tga',      'Boss',), # moon - boss
    
    ]