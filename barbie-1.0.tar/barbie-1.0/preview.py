import sys ; sys.argv.extend(['-full'])
#import sys ; sys.argv.extend(['-nosound','-full'])
import run_game
